var searchData=
[
  ['position_5fprotein',['position_protein',['../classMatch__found.html#a04eecccb0e71287b890e7c5a7081b6fb',1,'Match_found']]],
  ['position_5fread',['position_read',['../classMatch__found.html#ab7e5a1f16356377ea64205e3fac8ad82',1,'Match_found']]]
];
