var searchData=
[
  ['strsetsa',['StrSetSA',['../own__functions_8h.html#a909ec88b249602a3ccd98d1de277c602',1,'own_functions.h']]]
];
