var searchData=
[
  ['end_5fprotein',['end_protein',['../classMatch__found.html#a0a79a04cdb9a211d02f77ebfd6ec6a39',1,'Match_found']]],
  ['end_5fread',['end_read',['../classMatch__found.html#a8fe70d587e9a35fb75873acbc4506cf7',1,'Match_found']]]
];
