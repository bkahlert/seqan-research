var searchData=
[
  ['check_5fvalues',['CHECK_VALUES',['../own__functions_8h.html#a920ecd5ac06d3f904bd00844959becd4',1,'CHECK_VALUES(Variable &amp;comVal, StringSet&lt; String&lt; Dna &gt; &gt; &amp;Reads):&#160;parse_arguments.cpp'],['../parse__arguments_8cpp.html#a551054e394178089664364bca0c06cea',1,'CHECK_VALUES(Variable &amp;comVal, StringSet&lt; String&lt; Dna &gt; &gt; &amp;reads):&#160;parse_arguments.cpp']]]
];
