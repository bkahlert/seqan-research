var searchData=
[
  ['talign',['TAlign',['../own__functions_8h.html#a58673c1b373dd218c46a532433237416',1,'own_functions.h']]],
  ['tstringsetiterator',['TStringSetIterator',['../own__functions_8h.html#adb1a6e65b9cecc0a05822e551b2fa932',1,'own_functions.h']]]
];
