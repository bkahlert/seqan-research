var searchData=
[
  ['parse_5farguments',['PARSE_ARGUMENTS',['../own__functions_8h.html#a60357a02b7e70dcb2060ff734a63372f',1,'PARSE_ARGUMENTS(int argc, char const **argv, Variable &amp;comVal):&#160;parse_arguments.cpp'],['../parse__arguments_8cpp.html#a60357a02b7e70dcb2060ff734a63372f',1,'PARSE_ARGUMENTS(int argc, char const **argv, Variable &amp;comVal):&#160;parse_arguments.cpp']]],
  ['parse_5farguments_2ecpp',['parse_arguments.cpp',['../parse__arguments_8cpp.html',1,'']]],
  ['position_5fprotein',['position_protein',['../classMatch__found.html#a04eecccb0e71287b890e7c5a7081b6fb',1,'Match_found']]],
  ['position_5fread',['position_read',['../classMatch__found.html#ab7e5a1f16356377ea64205e3fac8ad82',1,'Match_found']]]
];
