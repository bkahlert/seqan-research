var searchData=
[
  ['score',['score',['../classMatch__found.html#ae6e0da6ff43d3f9f1ad1fcbd206e35a3',1,'Match_found']]],
  ['seed',['seed',['../classVariable.html#a53222e817e0a79e4adc658494d9a52d8',1,'Variable']]],
  ['size_5falp',['size_alp',['../classVariable.html#a8739cdae179653b93c2942e6039e52ba',1,'Variable']]]
];
