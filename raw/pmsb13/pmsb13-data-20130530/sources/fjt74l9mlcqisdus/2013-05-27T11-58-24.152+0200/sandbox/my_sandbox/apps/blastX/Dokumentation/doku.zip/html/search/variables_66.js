var searchData=
[
  ['fasta_5ffile',['fasta_file',['../classVariable.html#a0b50dd36eefa7a5c04159f7cfc38721c',1,'Variable']]],
  ['fastq_5ffile',['fastq_file',['../classVariable.html#ad1f7e3882a463fe98d199785848dc2b7',1,'Variable']]]
];
