var searchData=
[
  ['talign',['TAlign',['../own__functions_8h.html#a58673c1b373dd218c46a532433237416',1,'own_functions.h']]],
  ['test_5ffile_2ecpp',['test_file.cpp',['../test__file_8cpp.html',1,'']]],
  ['translate',['translate',['../own__functions_8h.html#adc092102c6d8790faf74b36da4690221',1,'translate(StrSetSA &amp;trans_reads, String&lt; Dna &gt; &amp;read, String&lt; AminoAcid &gt; &amp;alphabet, int frame, int reduced):&#160;translate.cpp'],['../translate_8cpp.html#adc092102c6d8790faf74b36da4690221',1,'translate(StrSetSA &amp;trans_reads, String&lt; Dna &gt; &amp;read, String&lt; AminoAcid &gt; &amp;alphabet, int frame, int reduced):&#160;translate.cpp']]],
  ['translate_2ecpp',['translate.cpp',['../translate_8cpp.html',1,'']]],
  ['translate_5fdatabase',['TRANSLATE_DATABASE',['../own__functions_8h.html#a3a551eef823f59dedd5b57aafae75deb',1,'TRANSLATE_DATABASE(StrSetSA &amp;trans_proteine, StrSetSA &amp;proteine, String&lt; AminoAcid &gt; &amp;alphabet):&#160;translate.cpp'],['../translate_8cpp.html#a3a551eef823f59dedd5b57aafae75deb',1,'TRANSLATE_DATABASE(StrSetSA &amp;trans_proteine, StrSetSA &amp;proteine, String&lt; AminoAcid &gt; &amp;alphabet):&#160;translate.cpp']]],
  ['translate_5freads',['TRANSLATE_READS',['../own__functions_8h.html#ae6211f2f39150602a311a5c9ff9d5969',1,'TRANSLATE_READS(StringSet&lt; String&lt; Dna &gt; &gt; &amp;reads, StrSetSA &amp;trans_reads, String&lt; AminoAcid &gt; &amp;alphabet, int reduced):&#160;translate.cpp'],['../translate_8cpp.html#ae6211f2f39150602a311a5c9ff9d5969',1,'TRANSLATE_READS(StringSet&lt; String&lt; Dna &gt; &gt; &amp;reads, StrSetSA &amp;trans_reads, String&lt; AminoAcid &gt; &amp;alphabet, int reduced):&#160;translate.cpp']]],
  ['tstringsetiterator',['TStringSetIterator',['../own__functions_8h.html#adb1a6e65b9cecc0a05822e551b2fa932',1,'own_functions.h']]]
];
