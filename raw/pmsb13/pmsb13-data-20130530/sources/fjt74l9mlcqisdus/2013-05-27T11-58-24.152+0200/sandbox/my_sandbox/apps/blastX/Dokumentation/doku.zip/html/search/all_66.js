var searchData=
[
  ['fasta_5ffile',['fasta_file',['../classVariable.html#a0b50dd36eefa7a5c04159f7cfc38721c',1,'Variable']]],
  ['fastq_5ffile',['fastq_file',['../classVariable.html#ad1f7e3882a463fe98d199785848dc2b7',1,'Variable']]],
  ['find_5fmatches',['FIND_MATCHES',['../finder_8cpp.html#a0e480959dbc9e470420a284212589067',1,'FIND_MATCHES(StrSetSA &amp;trans_proteine, StrSetSA &amp;trans_reads, unsigned &amp;seed, unsigned &amp;distance, Match_found &amp;seed_found):&#160;finder.cpp'],['../own__functions_8h.html#a0e480959dbc9e470420a284212589067',1,'FIND_MATCHES(StrSetSA &amp;trans_proteine, StrSetSA &amp;trans_reads, unsigned &amp;seed, unsigned &amp;distance, Match_found &amp;seed_found):&#160;finder.cpp']]],
  ['finder_2ecpp',['finder.cpp',['../finder_8cpp.html',1,'']]]
];
