var searchData=
[
  ['sandbox_5fmy_5fsandbox_5fapps_5fblastx_5fown_5ffunctions_5f',['SANDBOX_MY_SANDBOX_APPS_BLASTX_OWN_FUNCTIONS_',['../own__functions_8h.html#a7df5886f7964e2dc5f1ec16706bebd11',1,'own_functions.h']]],
  ['seqan_5fenable_5ftesting',['SEQAN_ENABLE_TESTING',['../test__file_8cpp.html#af5e41deb7713e3afae70b9c1f9221ea5',1,'test_file.cpp']]]
];
