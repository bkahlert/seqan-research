var searchData=
[
  ['variable',['Variable',['../classVariable.html',1,'']]]
];
