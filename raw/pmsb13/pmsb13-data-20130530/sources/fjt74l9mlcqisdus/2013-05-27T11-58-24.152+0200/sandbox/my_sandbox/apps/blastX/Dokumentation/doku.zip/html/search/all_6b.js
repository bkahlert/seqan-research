var searchData=
[
  ['known_5fposition',['known_position',['../own__functions_8h.html#a9d930342933ef0e01d29e46824f5e4a2',1,'known_position(unsigned &amp;begin, unsigned &amp;end, StringSet&lt; Pair&lt; unsigned int, unsigned int &gt; &gt; &amp;pair_position):&#160;own_functions.h'],['../verify_8cpp.html#a5a505c35ae7807a43d1764bab5a9fb73',1,'known_position(unsigned &amp;begin, unsigned &amp;end, StringSet&lt; Pair&lt; unsigned, unsigned &gt; &gt; &amp;pair_position):&#160;verify.cpp']]]
];
