var searchData=
[
  ['begin_5fprotein',['begin_protein',['../classMatch__found.html#a01587a9817e01713d5f0c53ae1654067',1,'Match_found']]],
  ['begin_5fread',['begin_read',['../classMatch__found.html#af80727f7da879d79e8ba7ae8e1dc4c48',1,'Match_found']]]
];
