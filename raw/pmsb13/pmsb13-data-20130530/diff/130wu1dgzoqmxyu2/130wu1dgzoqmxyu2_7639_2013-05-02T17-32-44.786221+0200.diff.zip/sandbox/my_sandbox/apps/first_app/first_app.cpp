#include <iostream>
#include <seqan/index.h>
#include <seqan/seeds.h>
#include <vector>

using namespace seqan;
using namespace std;

seqan::String<Seed<Simple> > get_global_seed_chain(seqan::DnaString &seq1, seqan::DnaString &seq2, unsigned q){

	typedef seqan::SeedSet<Simple> SSeedSet;
	typedef seqan::Seed<Simple> SSeed;
	SSeedSet set;

	seqan::String<Seed<Simple> > chain;

	seqan::Score<int, seqan::Simple> scoringScheme(1, -1, -1);

	typedef Index< DnaString, IndexQGram<SimpleShape > > qGramIndex;
	qGramIndex index(seq1);

	resize(indexShape(index), q);

	Finder<qGramIndex> myFinder(index);
	std::cout << length(seq2) << std::endl;

	for (unsigned i = 0; i < length(seq2) - (q - 1); ++i){
		DnaString qGram = infix(seq2, i, i + q);
		std::cout << "qGram: " << qGram << std::endl;

		while (find(myFinder, qGram)){
			std::cout << position(myFinder) << std::endl;
			SSeed seed(position(myFinder), i, position(myFinder) + q, i + q);
			if (!addSeed(set, seed, 2, 2, scoringScheme, seq1, seq2, seqan::Chaos())){
				addSeed(set, seed, seqan::Single());
			}
		}
		clear(myFinder);
	}

	seqan::chainSeedsGlobally(chain, set, seqan::SparseChaining());

	return chain;
}

int main(){
	typedef seqan::Seed<Simple> SSeed;
	DnaString window1 = "AAAACACGCGGTC";
	DnaString window2 = "GGTCGACCGT";
	seqan::String<SSeed> tempChain;
	std::vector<pair<unsigned, seqan::String<SSeed> > > recursionContainer;
	const unsigned t = 5 + 3;
	std::cout << t;

	/*
	std::vector<unsigned> a;
	unsigned q = 2;
	typedef Index< DnaString, IndexQGram<SimpleShape > > qGramIndex;
	qGramIndex index(window1);
	resize(indexShape(index), q);
	Finder<qGramIndex> myFinder(index);
	std::cout << length(window2) << std::endl;
	for (unsigned i = 0; i < length(window2) - (q - 1); ++i){
		DnaString qGram = infix(window2, i, i + q);
		std::cout << qGram << std::endl;
		while (find(myFinder, qGram)){
			a.push_back(position(myFinder));
			std::cout << position(myFinder) << std::endl;

		}
		clear(myFinder);

	}
	std::cout << a.size() << std::endl;
	for (unsigned i = 0; i < a.size(); ++i){
		std::cout << a[i] << std::endl;
	}*/
	return 0;
}
