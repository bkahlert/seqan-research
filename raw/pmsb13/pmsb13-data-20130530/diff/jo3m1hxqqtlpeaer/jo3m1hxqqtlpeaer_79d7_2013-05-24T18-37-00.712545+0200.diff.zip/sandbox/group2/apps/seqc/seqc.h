#include <seqan/basic.h>
#include <seqan/sequence.h>
#include <seqan/arg_parse.h>
#include <iostream>
#include <ios>
#include <fstream>
#include <climits>
#include <sstream>
#include <seqan/sequence.h>
#include <seqan/seq_io.h>


