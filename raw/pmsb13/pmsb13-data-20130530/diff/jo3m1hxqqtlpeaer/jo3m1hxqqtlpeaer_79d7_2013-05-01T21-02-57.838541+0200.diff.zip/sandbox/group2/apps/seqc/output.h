#ifndef __OUTPUT_H
#define __OUTPUT_H
#include "read_stats.h"

struct TSVWriter{
   
    int writeReadLength(ReadStats & stats);
    int writeAll(ReadStats & stats, char * outdir);
    int writePerPosQual(ReadStats & stats);

    private:
        std::ofstream ofStream;

        
};

#endif
