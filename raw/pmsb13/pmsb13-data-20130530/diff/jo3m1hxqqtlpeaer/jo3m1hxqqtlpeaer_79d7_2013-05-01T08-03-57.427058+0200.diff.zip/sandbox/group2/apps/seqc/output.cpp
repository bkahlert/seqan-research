#include <iostream>
#include <fstream>

#include "output.h"


int TSVWriter::writeAll(ReadStats const & stats){
    
}

int TSVWriter::writeReadLength(ReadStats const & stats)
{    
    // write out stats
    std::ofstream rlf;
    rlf.open("readlength.tsv");
    rlf << "length" << "\t" << "no_of_reads" << std::endl;
    std::map<int,int>::iterator iter; 
   
    for(iter=stats.readLenCount.begin();iter != stats.readLenCount.end(); iter++){
        rlf << iter->first << "\t" << iter->second << std::endl;
    }
    rlf.close();

};

