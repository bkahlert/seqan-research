#include <iostream>
#include <seqan/find.h>

using namespace seqan;
using namespace std;

int main()
{
    CharString haystack = "Simon, send more money!";
    String<CharString> needles;
    appendValue(needles, "mo");
    appendValue(needles, "send");
    appendValue(needles, "more");
    
    Finder<CharString> finder(haystack);
    Pattern<CharString, Horspool> pattern(needles);
    while (find(finder, pattern))
        std::cout << '[' << beginPosition(finder) << ',' << endPosition(finder) << ")\t" << infix(finder) << std::endl;

    return 0;
}
