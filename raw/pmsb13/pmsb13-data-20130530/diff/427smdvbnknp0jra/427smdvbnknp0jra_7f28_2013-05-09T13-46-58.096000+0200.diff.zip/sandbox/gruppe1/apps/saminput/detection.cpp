#include "detection.h"


detection::detection(void)
{
}


detection::~detection(void)
{std::nth_element( begin(input.len), begin(input.len) + input.length()/2,end(input.len) );
	return (unsigned)(begin(input.len) + input.length()/2 );
}
