#include "detection.h"


detection::detection(void)
{
}


detection::~detection(void)
{
}
