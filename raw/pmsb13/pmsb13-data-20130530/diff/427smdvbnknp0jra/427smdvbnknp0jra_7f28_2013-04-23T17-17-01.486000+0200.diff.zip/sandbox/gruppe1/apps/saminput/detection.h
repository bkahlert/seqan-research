#pragma once
class detection
{
public:
	detection(void);
	~detection(void);
};

