#include "read_stats.h"

struct Outputter{

    writeReadLength(ReadStats const & stats);
};
