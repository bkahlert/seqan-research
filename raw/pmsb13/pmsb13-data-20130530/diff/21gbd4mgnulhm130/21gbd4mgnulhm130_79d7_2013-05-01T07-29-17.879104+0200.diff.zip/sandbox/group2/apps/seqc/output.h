#include "read_stats.h"

struct Outputter{

    int  writeReadLength(ReadStats const & stats);
};
