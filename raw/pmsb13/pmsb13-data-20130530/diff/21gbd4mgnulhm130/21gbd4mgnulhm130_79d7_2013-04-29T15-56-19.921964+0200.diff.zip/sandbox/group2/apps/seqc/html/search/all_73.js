var searchData=
[
  ['scorecount',['scoreCount',['../structReadStats.html#a301a09b8d357a68ece8140731f0c7a62',1,'ReadStats']]]
];
