var searchData=
[
  ['readlencount',['readLenCount',['../structReadStats.html#a2f389e19dcd24901f024df8e3cb41b25',1,'ReadStats']]],
  ['readstats',['ReadStats',['../structReadStats.html',1,'ReadStats'],['../structReadStats.html#a42157da1cf5611d9d6dc7446f1aeffaf',1,'ReadStats::ReadStats()']]]
];
