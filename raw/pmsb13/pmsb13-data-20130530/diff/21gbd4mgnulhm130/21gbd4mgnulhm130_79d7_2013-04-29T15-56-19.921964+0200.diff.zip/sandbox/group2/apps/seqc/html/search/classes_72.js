var searchData=
[
  ['readstats',['ReadStats',['../structReadStats.html',1,'']]]
];
