var searchData=
[
  ['collectreadstats',['collectReadStats',['../structReadStats.html#aa61f5f9bb9e9302e0b22e6909c52762c',1,'ReadStats']]]
];
