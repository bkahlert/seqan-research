var searchData=
[
  ['readstats',['ReadStats',['../structReadStats.html#a42157da1cf5611d9d6dc7446f1aeffaf',1,'ReadStats']]]
];
