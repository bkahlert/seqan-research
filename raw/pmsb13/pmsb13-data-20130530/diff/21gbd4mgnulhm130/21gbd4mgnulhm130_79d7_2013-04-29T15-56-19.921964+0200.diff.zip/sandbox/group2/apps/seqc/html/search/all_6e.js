var searchData=
[
  ['nuccount',['nucCount',['../structReadStats.html#aa8ce6cf2b6feee564b6d30190f5e9229',1,'ReadStats']]]
];
