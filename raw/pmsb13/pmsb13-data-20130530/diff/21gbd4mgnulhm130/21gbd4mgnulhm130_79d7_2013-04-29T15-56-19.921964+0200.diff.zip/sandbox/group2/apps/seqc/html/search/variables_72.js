var searchData=
[
  ['readlencount',['readLenCount',['../structReadStats.html#a2f389e19dcd24901f024df8e3cb41b25',1,'ReadStats']]]
];
