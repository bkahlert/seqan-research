
struct Outputter{

    writeReadLength(const & ReadStats stats);
};
