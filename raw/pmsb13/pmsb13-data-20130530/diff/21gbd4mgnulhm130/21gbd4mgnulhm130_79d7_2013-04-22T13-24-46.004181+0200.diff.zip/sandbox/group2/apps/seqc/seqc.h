
struct ReadStats{
    
    String<String <unsigned> > scoreCount;
    String<String <unsigned> > nucCount;

    ReadStats(unsigned readLength);

    void toString();
};


