#include "read_stats.h";

struct Outputter{

    writeReadLength(const & ReadStats stats);
};
