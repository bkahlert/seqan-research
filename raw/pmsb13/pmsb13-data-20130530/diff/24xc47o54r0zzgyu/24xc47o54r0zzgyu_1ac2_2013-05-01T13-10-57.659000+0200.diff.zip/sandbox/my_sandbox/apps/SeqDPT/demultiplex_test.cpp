#undef SEQAN_ENABLE_TESTING
#define SEQAN_ENABLE_TESTING 1

#include <seqan/basic.h>
#include <seqan/sequence.h>
#include <seqan/seq_io.h>
#include <seqan/file.h>


SEQAN_DEFINE_TEST(sliding_window_test_qual)
{

}

SEQAN_BEGIN_TESTSUITE(test_my_app_funcs)
{
 
}
SEQAN_END_TESTSUITE
