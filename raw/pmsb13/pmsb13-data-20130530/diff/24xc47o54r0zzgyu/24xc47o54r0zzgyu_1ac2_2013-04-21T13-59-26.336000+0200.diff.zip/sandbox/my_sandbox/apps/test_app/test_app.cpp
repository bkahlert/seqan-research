#include <seqan\file.h>

int main()
{
// Nur ein Test
std::cout<<"Nur ein Test f�rs SVN..."<<std::endl;
return 0;
}