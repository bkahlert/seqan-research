var searchData=
[
  ['buildsets',['buildSets',['../demultiplex_8h.html#a1b5de89336b8aec313bd0de7c5d308ee',1,'buildSets(TSeqs &amp;seqs, TSeqs &amp;seqsRev, TIds &amp;ids, TIds &amp;idsRev, const std::vector&lt; std::vector&lt; int &gt; &gt; &amp;groups, std::vector&lt; TSeqs &gt; &amp;gSeqs, std::vector&lt; TSeqs &gt; &amp;gSeqsRev, std::vector&lt; TIds &gt; &amp;gIds, std::vector&lt; TIds &gt; &amp;gIdsRev):&#160;demultiplex.h'],['../demultiplex_8h.html#a0f8743c5f7be560f5525171fa3d57048',1,'buildSets(TSeqs &amp;seqs, TIds &amp;ids, const std::vector&lt; std::vector&lt; int &gt; &gt; &amp;groups, std::vector&lt; TSeqs &gt; &amp;gSeqs, std::vector&lt; TIds &gt; &amp;gIds):&#160;demultiplex.h']]]
];
