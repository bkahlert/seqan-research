var searchData=
[
  ['demultiplex_2eh',['demultiplex.h',['../demultiplex_8h.html',1,'']]],
  ['demultiplexingparams',['DemultiplexingParams',['../struct_demultiplexing_params.html',1,'']]],
  ['dna5qadapter',['Dna5QAdapter',['../struct_dna5_q_adapter.html',1,'']]],
  ['doall',['DoAll',['../demultiplex_8h.html#a16fbfbe3644c26833a0772c7be1ab289',1,'DoAll(TMultiplex &amp;multiplex, TBarcodes &amp;barcodes, TFinder &amp;esaFinder):&#160;demultiplex.h'],['../demultiplex_8h.html#a2f64bea7fe94ec2e18a0613661e44ee1',1,'DoAll(TMultiplex &amp;multiplex, TBarcodes &amp;barcodes):&#160;demultiplex.h'],['../demultiplex_8h.html#a5423da623cd020757b86e36f6132baab',1,'DoAll(TSeqs &amp;seqs, TBarcodes &amp;barcodes, TFinder &amp;esaFinder, bool hardClip):&#160;demultiplex.h'],['../demultiplex_8h.html#a7116cdb768b8e618de1e539c0baba841',1,'DoAll(TSeqs &amp;seqs, TBarcodes &amp;barcodes, bool hardClip):&#160;demultiplex.h']]],
  ['dropreads',['dropReads',['../read_trimming_8h.html#aab5753193ec94615160b06e41cf41081',1,'dropReads(seqan::StringSet&lt; TId &gt; &amp;idSet, seqan::StringSet&lt; TSeq &gt; &amp;seqSet, unsigned const min_length, QualityTrimmingStats &amp;stats):&#160;readTrimming.h'],['../read_trimming_8h.html#af42667d2b5578b36c5139254b2db2d89',1,'dropReads(seqan::StringSet&lt; TId &gt; &amp;idSet1, seqan::StringSet&lt; TSeq &gt; &amp;seqSet1, seqan::StringSet&lt; TId &gt; &amp;idSet2, seqan::StringSet&lt; TSeq &gt; &amp;seqSet2, unsigned const min_length, QualityTrimmingStats &amp;stats):&#160;readTrimming.h']]]
];
