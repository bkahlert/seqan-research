var searchData=
[
  ['removevalues',['removeValues',['../read_trimming_8h.html#a26243ec33bde09878c5a81d3074a9c57',1,'readTrimming.h']]],
  ['resizegroups',['resizeGroups',['../demultiplex_8h.html#ab8570a5ec49e672244deb3ec94154906',1,'demultiplex.h']]]
];
