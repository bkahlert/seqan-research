var searchData=
[
  ['makepatterns',['makePatterns',['../demultiplex_8h.html#ac36c5f6999d5913d122814e156ccbf4d',1,'demultiplex.h']]]
];
