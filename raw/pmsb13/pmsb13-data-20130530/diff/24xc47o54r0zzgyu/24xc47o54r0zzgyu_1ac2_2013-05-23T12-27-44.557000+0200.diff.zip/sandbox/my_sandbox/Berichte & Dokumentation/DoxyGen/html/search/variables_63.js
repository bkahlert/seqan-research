var searchData=
[
  ['cutoff',['cutoff',['../struct_quality_trimming_params.html#a3b2b268123a0054eda2f603e7be590dc',1,'QualityTrimmingParams']]]
];
