var searchData=
[
  ['adapterscoringmatrix',['AdapterScoringMatrix',['../structseqan_1_1_adapter_scoring_matrix.html',1,'seqan']]],
  ['adaptertrimmingparams',['AdapterTrimmingParams',['../struct_adapter_trimming_params.html',1,'']]],
  ['adaptertrimmingstats',['AdapterTrimmingStats',['../struct_adapter_trimming_stats.html',1,'']]],
  ['auto',['Auto',['../struct_auto.html',1,'']]]
];
