var searchData=
[
  ['erase',['erase',['../read_trimming_8h.html#aa6e7d909096e031df27e38d40bf3cba8',1,'readTrimming.h']]],
  ['errors',['errors',['../struct_user.html#a8622c0446a3a49852b69c5d558a62d7c',1,'User']]],
  ['exists',['exists',['../class_output_streams.html#a14babf33ab80c1dd5d158f2ddd9d5625',1,'OutputStreams']]]
];
