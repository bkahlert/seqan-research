var searchData=
[
  ['barcodefile',['barcodeFile',['../struct_demultiplexing_params.html#a2b2b682fbf21f3ca8daafe3e9b83c0ca',1,'DemultiplexingParams']]],
  ['barcodeids',['barcodeIds',['../struct_demultiplexing_params.html#a1721fa9ad83112b0d2df9c2932bd00be',1,'DemultiplexingParams']]],
  ['barcodes',['barcodes',['../struct_demultiplexing_params.html#aaeea114c00f19f6565047e507a74f90f',1,'DemultiplexingParams']]]
];
