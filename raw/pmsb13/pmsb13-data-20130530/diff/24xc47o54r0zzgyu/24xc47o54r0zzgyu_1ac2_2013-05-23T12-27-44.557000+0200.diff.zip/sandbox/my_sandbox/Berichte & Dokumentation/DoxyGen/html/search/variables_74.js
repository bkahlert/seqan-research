var searchData=
[
  ['trim_5fmode',['trim_mode',['../struct_quality_trimming_params.html#a048e76b525de1500f55f39e9e572ab80',1,'QualityTrimmingParams']]]
];
