var searchData=
[
  ['readtrimming_2eh',['readTrimming.h',['../read_trimming_8h.html',1,'']]],
  ['removevalues',['removeValues',['../read_trimming_8h.html#a26243ec33bde09878c5a81d3074a9c57',1,'readTrimming.h']]],
  ['resizegroups',['resizeGroups',['../demultiplex_8h.html#ab8570a5ec49e672244deb3ec94154906',1,'demultiplex.h']]],
  ['run',['run',['../struct_demultiplexing_params.html#a4a52e0b0dbbacf3e1d4e2b115f3d8cf7',1,'DemultiplexingParams::run()'],['../struct_adapter_trimming_params.html#a61f37e8fe2d242947cfd358b85a0380e',1,'AdapterTrimmingParams::run()'],['../struct_quality_trimming_params.html#a1b2db8d78cae5e3db9d8fc903e042310',1,'QualityTrimmingParams::run()']]],
  ['runx',['runx',['../struct_demultiplexing_params.html#aa7bf93a371b34c9ad7ae0a5dc8edc8c5',1,'DemultiplexingParams']]]
];
