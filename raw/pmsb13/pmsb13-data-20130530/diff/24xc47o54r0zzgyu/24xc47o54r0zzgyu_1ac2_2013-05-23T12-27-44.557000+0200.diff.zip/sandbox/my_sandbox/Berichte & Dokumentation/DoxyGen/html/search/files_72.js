var searchData=
[
  ['readtrimming_2eh',['readTrimming.h',['../read_trimming_8h.html',1,'']]]
];
