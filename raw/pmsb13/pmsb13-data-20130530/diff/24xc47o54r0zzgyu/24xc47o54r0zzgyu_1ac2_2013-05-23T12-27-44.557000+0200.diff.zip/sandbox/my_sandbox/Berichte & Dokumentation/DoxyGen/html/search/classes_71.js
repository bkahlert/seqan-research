var searchData=
[
  ['qualitytrimmingparams',['QualityTrimmingParams',['../struct_quality_trimming_params.html',1,'']]],
  ['qualitytrimmingstats',['QualityTrimmingStats',['../struct_quality_trimming_stats.html',1,'']]]
];
