var searchData=
[
  ['_5ftrimread',['_trimRead',['../read_trimming_8h.html#a5c2564491957a121f99d11b1beb0c87a',1,'_trimRead(const TSeq &amp;seq, unsigned const cutoff, Tail const &amp;):&#160;readTrimming.h'],['../read_trimming_8h.html#aa5246d3d39615311f5a9c08c5ebc5275',1,'_trimRead(const TSeq &amp;seq, unsigned const cutoff, BWA const &amp;):&#160;readTrimming.h'],['../read_trimming_8h.html#a012119ccfbc2dc4593e80fc3ad545935',1,'_trimRead(const TSeq &amp;seq, unsigned const _cutoff, Mean const &amp;spec):&#160;readTrimming.h']]],
  ['_5ftrimreads',['_trimReads',['../read_trimming_8h.html#a818bc0bf0d601b8b75ba685dd15879f7',1,'readTrimming.h']]]
];
