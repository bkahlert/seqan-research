var searchData=
[
  ['mean',['Mean',['../struct_mean.html',1,'']]],
  ['mode',['Mode',['../struct_mode.html',1,'']]]
];
