var searchData=
[
  ['demultiplex_2eh',['demultiplex.h',['../demultiplex_8h.html',1,'']]],
  ['demultiplexingparams',['DemultiplexingParams',['../struct_demultiplexing_params.html',1,'']]],
  ['demultiplexstats',['DemultiplexStats',['../struct_demultiplex_stats.html',1,'']]],
  ['dna5qadapter',['Dna5QAdapter',['../struct_dna5_q_adapter.html',1,'']]],
  ['doall',['DoAll',['../demultiplex_8h.html#a07f4a4bff8995b9ea9cd8e5d8ff0ddfd',1,'DoAll(TMultiplex &amp;multiplex, TBarcodes &amp;barcodes, TFinder &amp;esaFinder, TStats &amp;stats):&#160;demultiplex.h'],['../demultiplex_8h.html#af01bbc92deb2f0e2457a65abe848f81b',1,'DoAll(TMultiplex &amp;multiplex, TBarcodes &amp;barcodes, TStats &amp;stats):&#160;demultiplex.h'],['../demultiplex_8h.html#a107b0a518ebc018518c2f223cc40c052',1,'DoAll(TSeqs &amp;seqs, TBarcodes &amp;barcodes, TFinder &amp;esaFinder, bool hardClip, TStats &amp;stats):&#160;demultiplex.h'],['../demultiplex_8h.html#aa740b5e5a2495ee090bca9d6685b2364',1,'DoAll(TSeqs &amp;seqs, TBarcodes &amp;barcodes, bool hardClip, TStats &amp;stats):&#160;demultiplex.h']]],
  ['dropreads',['dropReads',['../read_trimming_8h.html#aab5753193ec94615160b06e41cf41081',1,'dropReads(seqan::StringSet&lt; TId &gt; &amp;idSet, seqan::StringSet&lt; TSeq &gt; &amp;seqSet, unsigned const min_length, QualityTrimmingStats &amp;stats):&#160;readTrimming.h'],['../read_trimming_8h.html#af42667d2b5578b36c5139254b2db2d89',1,'dropReads(seqan::StringSet&lt; TId &gt; &amp;idSet1, seqan::StringSet&lt; TSeq &gt; &amp;seqSet1, seqan::StringSet&lt; TId &gt; &amp;idSet2, seqan::StringSet&lt; TSeq &gt; &amp;seqSet2, unsigned const min_length, QualityTrimmingStats &amp;stats):&#160;readTrimming.h']]]
];
