var searchData=
[
  ['getinsertsize',['getInsertSize',['../adapter_trimming_8h.html#a8427805bc99660a9476176b62061f45f',1,'adapterTrimming.h']]],
  ['getoverlap',['getOverlap',['../adapter_trimming_8h.html#af28bd342d3520fd7fe6e298e0271e288',1,'adapterTrimming.h']]],
  ['getprefix',['getPrefix',['../demultiplex_8h.html#a53164dfc669a1636d5fcb8b67e26545c',1,'demultiplex.h']]],
  ['getquality',['getQuality',['../read_trimming_8h.html#aabaf57d5f62dfb5270a79b367c5c8a9d',1,'getQuality(const seqan::String&lt; seqan::Dna5Q &gt; &amp;seq, unsigned i):&#160;readTrimming.h'],['../read_trimming_8h.html#a73e688ebd64d5101bf3ac782c886b705',1,'getQuality(const Dna5QAdapter &amp;seq, unsigned i):&#160;readTrimming.h']]],
  ['group',['group',['../demultiplex_8h.html#a51c1b637cfe518cdb968089aab2fb462',1,'demultiplex.h']]],
  ['groups',['groups',['../struct_demultiplex_stats.html#a92d012f999200b860f2e4ad664164ccb',1,'DemultiplexStats']]]
];
