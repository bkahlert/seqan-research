var searchData=
[
  ['scoringmatrixdata_5f_3c_20int_2c_20dna5_2c_20adapterscoringmatrix_20_3e',['ScoringMatrixData_&lt; int, Dna5, AdapterScoringMatrix &gt;',['../structseqan_1_1_scoring_matrix_data___3_01int_00_01_dna5_00_01_adapter_scoring_matrix_01_4.html',1,'seqan']]],
  ['seq',['seq',['../struct_dna5_q_adapter.html#adbb31f790426215e45b4816c48e0e671',1,'Dna5QAdapter']]],
  ['stats',['stats',['../struct_demultiplexing_params.html#a1017a69229d12a8a3714f80e75c3dbb9',1,'DemultiplexingParams::stats()'],['../struct_adapter_trimming_params.html#a557d501f056a0ba2ae35560ed8d72a9d',1,'AdapterTrimmingParams::stats()'],['../struct_quality_trimming_params.html#a5f07878380511531b124c6f94a611b91',1,'QualityTrimmingParams::stats()']]],
  ['string_5freverse_5fcomplement',['STRING_REVERSE_COMPLEMENT',['../struct_s_t_r_i_n_g___r_e_v_e_r_s_e___c_o_m_p_l_e_m_e_n_t.html',1,'']]],
  ['stripadapter',['stripAdapter',['../adapter_trimming_8h.html#a7f0ed5b254d423dabfb235c79355242d',1,'adapterTrimming.h']]],
  ['stripadapterbatch',['stripAdapterBatch',['../adapter_trimming_8h.html#a3c85c17ed0ce3241d328d9b609d88789',1,'adapterTrimming.h']]],
  ['strippair',['stripPair',['../adapter_trimming_8h.html#a502e2eb7a85e1f67dd637e94f1600524',1,'stripPair(TSeq &amp;seq1, TSeq &amp;seq2):&#160;adapterTrimming.h'],['../adapter_trimming_8h.html#aeddd7c1ce0243088be7cde1b4cb5825c',1,'stripPair(TSeq &amp;seq1, TSeq &amp;adapter1, TSeq &amp;seq2, TSeq &amp;adapter2):&#160;adapterTrimming.h']]],
  ['strippairbatch',['stripPairBatch',['../adapter_trimming_8h.html#a390ded6489d24d870c5b63d57b394ad9',1,'adapterTrimming.h']]],
  ['stripreverseadapterbatch',['stripReverseAdapterBatch',['../adapter_trimming_8h.html#a388d9f7c52eada005728f2394f2bb7d2',1,'adapterTrimming.h']]]
];
