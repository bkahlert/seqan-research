var searchData=
[
  ['check',['check',['../demultiplex_8h.html#ac3b2d77bf5a4a5c24a5c6c39f2f14db2',1,'check(TSeqs &amp;seqs, TSeqs &amp;seqsRev, TIds &amp;ids, TBarcodes &amp;barcodes):&#160;demultiplex.h'],['../demultiplex_8h.html#a477c711488d93a6c74d678003d564f6e',1,'check(TSeqs &amp;seqs, TIds &amp;ids, TBarcodes &amp;barcodes):&#160;demultiplex.h']]],
  ['clipbarcodes',['clipBarcodes',['../demultiplex_8h.html#ab5a50e84f98a28e69180e1b7b9794e66',1,'clipBarcodes(TSeqs &amp;seqs, const std::vector&lt; int &gt; &amp;matches, unsigned len):&#160;demultiplex.h'],['../demultiplex_8h.html#afd6d6a19f9f658b9033c14f61bbd154f',1,'clipBarcodes(TSeqs &amp;seqs, int len):&#160;demultiplex.h']]],
  ['counttotalgaps',['countTotalGaps',['../adapter_trimming_8h.html#a3bc646d4dc99acf0ae165cf082e217cb',1,'adapterTrimming.h']]],
  ['cutoff',['cutoff',['../struct_quality_trimming_params.html#a3b2b268123a0054eda2f603e7be590dc',1,'QualityTrimmingParams']]]
];
