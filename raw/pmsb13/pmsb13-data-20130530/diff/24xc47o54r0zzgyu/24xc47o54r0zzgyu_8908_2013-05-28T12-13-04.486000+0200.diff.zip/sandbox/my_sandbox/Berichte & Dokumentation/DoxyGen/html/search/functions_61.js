var searchData=
[
  ['addstream',['addStream',['../class_output_streams.html#a57fe721eed419cf693ad16ac2d065783',1,'OutputStreams']]],
  ['addstreams',['addStreams',['../class_output_streams.html#ae724b4ed3aebd3ddd9d4426cdc6c856b',1,'OutputStreams']]],
  ['alignadapter',['alignAdapter',['../adapter_trimming_8h.html#a5c6fd3864a1835e6d7120555021326ee',1,'adapterTrimming.h']]],
  ['alignpair',['alignPair',['../adapter_trimming_8h.html#a690b4222b093c2260ab0522bff30049f',1,'adapterTrimming.h']]]
];
