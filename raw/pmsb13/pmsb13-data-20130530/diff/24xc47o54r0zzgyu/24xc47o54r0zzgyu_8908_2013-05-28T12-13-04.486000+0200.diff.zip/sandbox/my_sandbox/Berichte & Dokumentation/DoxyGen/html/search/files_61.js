var searchData=
[
  ['adaptertrimming_2eh',['adapterTrimming.h',['../adapter_trimming_8h.html',1,'']]]
];
