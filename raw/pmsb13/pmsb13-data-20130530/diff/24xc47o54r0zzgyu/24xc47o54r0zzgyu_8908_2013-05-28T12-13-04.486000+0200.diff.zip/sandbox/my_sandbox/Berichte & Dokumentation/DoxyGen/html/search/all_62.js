var searchData=
[
  ['barcodefile',['barcodeFile',['../struct_demultiplexing_params.html#a2b2b682fbf21f3ca8daafe3e9b83c0ca',1,'DemultiplexingParams']]],
  ['barcodeids',['barcodeIds',['../struct_demultiplexing_params.html#a1721fa9ad83112b0d2df9c2932bd00be',1,'DemultiplexingParams']]],
  ['barcodes',['barcodes',['../struct_demultiplexing_params.html#aaeea114c00f19f6565047e507a74f90f',1,'DemultiplexingParams']]],
  ['buildsets',['buildSets',['../demultiplex_8h.html#a1b5de89336b8aec313bd0de7c5d308ee',1,'buildSets(TSeqs &amp;seqs, TSeqs &amp;seqsRev, TIds &amp;ids, TIds &amp;idsRev, const std::vector&lt; std::vector&lt; int &gt; &gt; &amp;groups, std::vector&lt; TSeqs &gt; &amp;gSeqs, std::vector&lt; TSeqs &gt; &amp;gSeqsRev, std::vector&lt; TIds &gt; &amp;gIds, std::vector&lt; TIds &gt; &amp;gIdsRev):&#160;demultiplex.h'],['../demultiplex_8h.html#a0f8743c5f7be560f5525171fa3d57048',1,'buildSets(TSeqs &amp;seqs, TIds &amp;ids, const std::vector&lt; std::vector&lt; int &gt; &gt; &amp;groups, std::vector&lt; TSeqs &gt; &amp;gSeqs, std::vector&lt; TIds &gt; &amp;gIds):&#160;demultiplex.h']]],
  ['bwa',['BWA',['../struct_b_w_a.html',1,'']]]
];
