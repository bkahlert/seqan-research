var searchData=
[
  ['errors',['errors',['../struct_user.html#a8622c0446a3a49852b69c5d558a62d7c',1,'User']]]
];
