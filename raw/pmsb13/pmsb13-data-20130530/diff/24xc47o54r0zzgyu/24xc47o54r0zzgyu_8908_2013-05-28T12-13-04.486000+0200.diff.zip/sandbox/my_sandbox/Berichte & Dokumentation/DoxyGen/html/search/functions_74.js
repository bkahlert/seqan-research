var searchData=
[
  ['trimbatch',['trimBatch',['../read_trimming_8h.html#aef500404f94a868b4089f69bc0848ea2',1,'readTrimming.h']]],
  ['trimpairbatch',['trimPairBatch',['../read_trimming_8h.html#a75fd61ab491bb79116015f27ba1a4b9b',1,'readTrimming.h']]],
  ['trimread',['trimRead',['../read_trimming_8h.html#a99aa7d149d67d5e4ace1d99f2737e3d9',1,'trimRead(TSeq &amp;seq, TQual &amp;qual, unsigned const cutoff, TSpec const &amp;spec):&#160;readTrimming.h'],['../read_trimming_8h.html#ad7c9266b8f2b2486d5c27dc2daf71de6',1,'trimRead(TSeq &amp;seq, unsigned const cutoff, TSpec const &amp;spec):&#160;readTrimming.h']]]
];
