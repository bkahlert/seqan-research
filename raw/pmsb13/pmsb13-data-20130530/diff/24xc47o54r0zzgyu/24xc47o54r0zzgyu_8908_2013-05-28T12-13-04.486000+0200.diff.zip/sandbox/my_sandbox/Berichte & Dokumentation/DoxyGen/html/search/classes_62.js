var searchData=
[
  ['bwa',['BWA',['../struct_b_w_a.html',1,'']]]
];
