var searchData=
[
  ['maxoverlap',['maxOverlap',['../struct_adapter_trimming_stats.html#a3a8e65c4bb3dbd65a51289d07699ad11',1,'AdapterTrimmingStats']]],
  ['min_5flength',['min_length',['../struct_user.html#ae94113fb04b477ed27af1e0fe9e7822e',1,'User::min_length()'],['../struct_quality_trimming_params.html#a754750a0a278d17d82a02dedfbf185ba',1,'QualityTrimmingParams::min_length()']]],
  ['mmode',['mmode',['../struct_adapter_trimming_params.html#ae69ec37f149e6b9234746ae275c5ff3e',1,'AdapterTrimmingParams']]],
  ['mode',['mode',['../struct_adapter_trimming_params.html#a9e78ea3942b231eccb2243a70953c560',1,'AdapterTrimmingParams']]],
  ['multiplex',['multiplex',['../struct_demultiplexing_params.html#a6d5a685bccab390519e4b423018443f7',1,'DemultiplexingParams']]],
  ['multiplexfile',['multiplexFile',['../struct_demultiplexing_params.html#a93d9e02c35225dac383b7c52f7b539f7',1,'DemultiplexingParams']]]
];
