var searchData=
[
  ['noadapter',['noAdapter',['../struct_adapter_trimming_params.html#a8386f1819859d97bb58011903f5dd847',1,'AdapterTrimmingParams']]]
];
