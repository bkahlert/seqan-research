var searchData=
[
  ['ismatch',['isMatch',['../adapter_trimming_8h.html#a8d41cfe5174b6faee428503c8fd0fa45',1,'isMatch(int overlap, int mismatches, const Auto &amp;):&#160;adapterTrimming.h'],['../adapter_trimming_8h.html#acd23c187993f2c93b6c9177d7df4563f',1,'isMatch(int overlap, int mismatches, const User &amp;userOptions):&#160;adapterTrimming.h']]]
];
