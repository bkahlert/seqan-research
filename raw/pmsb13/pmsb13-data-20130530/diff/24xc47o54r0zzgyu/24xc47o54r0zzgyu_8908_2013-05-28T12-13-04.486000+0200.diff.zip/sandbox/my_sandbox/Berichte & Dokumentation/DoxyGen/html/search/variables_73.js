var searchData=
[
  ['seq',['seq',['../struct_dna5_q_adapter.html#adbb31f790426215e45b4816c48e0e671',1,'Dna5QAdapter']]],
  ['stats',['stats',['../struct_demultiplexing_params.html#a1017a69229d12a8a3714f80e75c3dbb9',1,'DemultiplexingParams::stats()'],['../struct_adapter_trimming_params.html#a557d501f056a0ba2ae35560ed8d72a9d',1,'AdapterTrimmingParams::stats()'],['../struct_quality_trimming_params.html#a5f07878380511531b124c6f94a611b91',1,'QualityTrimmingParams::stats()']]]
];
