var searchData=
[
  ['window',['window',['../struct_mean.html#ad9aa4cda35341999d3fba71f94f40be4',1,'Mean']]],
  ['writegroups',['writeGroups',['../demultiplex_8h.html#a7a471145751300d281f7de04b5fa66c3',1,'writeGroups(TgSeqs &amp;gSeqs, TgSeqs &amp;gSeqsRev, TgIds &amp;gIds, TBarcodeIds &amp;barcodeIds, std::vector&lt; std::vector&lt; int &gt; &gt; &amp;groups, String&lt; char &gt; &amp;path):&#160;demultiplex.h'],['../demultiplex_8h.html#a7d786671ac0782c001322ecece0465e9',1,'writeGroups(TgSeqs &amp;gSeqs, TgIds &amp;gIds, TBarcodeIds &amp;barcodeIds, Tgroups &amp;groups, String&lt; char &gt; &amp;path):&#160;demultiplex.h']]],
  ['writeseqs',['writeSeqs',['../class_output_streams.html#afcbc59e33ac5ea2487bd8db8dd3250c3',1,'OutputStreams::writeSeqs(TIds &amp;ids, TSeqs &amp;seqs, TMap &amp;map, TNames &amp;names)'],['../class_output_streams.html#a4e2742f8208c6b37d6d5177e500ddac3',1,'OutputStreams::writeSeqs(TIds &amp;ids1, TSeqs &amp;seqs1, TIds &amp;ids2, TSeqs &amp;seqs2, TMap &amp;map, TNames &amp;names)']]]
];
