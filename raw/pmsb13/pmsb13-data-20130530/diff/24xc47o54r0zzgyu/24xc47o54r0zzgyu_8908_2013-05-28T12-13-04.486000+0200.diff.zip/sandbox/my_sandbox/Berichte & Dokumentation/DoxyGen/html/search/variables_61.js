var searchData=
[
  ['a2count',['a2count',['../struct_adapter_trimming_stats.html#aabec417e43e59c829ab9172399c2961f',1,'AdapterTrimmingStats']]],
  ['adapter1',['adapter1',['../struct_adapter_trimming_params.html#a2ce2d426a36e328f4fceb715910db488',1,'AdapterTrimmingParams']]],
  ['adapter2',['adapter2',['../struct_adapter_trimming_params.html#aa7d555b99c145cd062e7caa12f4161ab',1,'AdapterTrimmingParams']]],
  ['approximate',['approximate',['../struct_demultiplexing_params.html#ae76872bea7b75ea020035f7825fc8210',1,'DemultiplexingParams']]]
];
