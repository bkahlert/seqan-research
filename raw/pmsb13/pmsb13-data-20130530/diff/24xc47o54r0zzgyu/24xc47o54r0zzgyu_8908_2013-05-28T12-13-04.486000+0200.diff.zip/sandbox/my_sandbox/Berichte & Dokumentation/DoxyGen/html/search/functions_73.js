var searchData=
[
  ['stripadapter',['stripAdapter',['../adapter_trimming_8h.html#a7f0ed5b254d423dabfb235c79355242d',1,'adapterTrimming.h']]],
  ['stripadapterbatch',['stripAdapterBatch',['../adapter_trimming_8h.html#a3c85c17ed0ce3241d328d9b609d88789',1,'adapterTrimming.h']]],
  ['strippair',['stripPair',['../adapter_trimming_8h.html#a502e2eb7a85e1f67dd637e94f1600524',1,'stripPair(TSeq &amp;seq1, TSeq &amp;seq2):&#160;adapterTrimming.h'],['../adapter_trimming_8h.html#aeddd7c1ce0243088be7cde1b4cb5825c',1,'stripPair(TSeq &amp;seq1, TSeq &amp;adapter1, TSeq &amp;seq2, TSeq &amp;adapter2):&#160;adapterTrimming.h']]],
  ['strippairbatch',['stripPairBatch',['../adapter_trimming_8h.html#a390ded6489d24d870c5b63d57b394ad9',1,'adapterTrimming.h']]],
  ['stripreverseadapterbatch',['stripReverseAdapterBatch',['../adapter_trimming_8h.html#a388d9f7c52eada005728f2394f2bb7d2',1,'adapterTrimming.h']]]
];
