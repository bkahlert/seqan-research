var searchData=
[
  ['window',['window',['../struct_mean.html#ad9aa4cda35341999d3fba71f94f40be4',1,'Mean']]]
];
