var searchData=
[
  ['scoringmatrixdata_5f_3c_20int_2c_20dna5_2c_20adapterscoringmatrix_20_3e',['ScoringMatrixData_&lt; int, Dna5, AdapterScoringMatrix &gt;',['../structseqan_1_1_scoring_matrix_data___3_01int_00_01_dna5_00_01_adapter_scoring_matrix_01_4.html',1,'seqan']]],
  ['string_5freverse_5fcomplement',['STRING_REVERSE_COMPLEMENT',['../struct_s_t_r_i_n_g___r_e_v_e_r_s_e___c_o_m_p_l_e_m_e_n_t.html',1,'']]]
];
