var searchData=
[
  ['updatestreams',['updateStreams',['../class_output_streams.html#aa807680b5625932c7cdd65c25023aaa3',1,'OutputStreams']]],
  ['user',['User',['../struct_user.html',1,'']]]
];
