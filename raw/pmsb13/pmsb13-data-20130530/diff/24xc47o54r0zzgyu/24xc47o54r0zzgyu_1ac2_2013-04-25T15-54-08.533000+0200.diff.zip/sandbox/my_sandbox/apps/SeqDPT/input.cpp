// Program part for parsing the input

int main()
{
	return 0;
}