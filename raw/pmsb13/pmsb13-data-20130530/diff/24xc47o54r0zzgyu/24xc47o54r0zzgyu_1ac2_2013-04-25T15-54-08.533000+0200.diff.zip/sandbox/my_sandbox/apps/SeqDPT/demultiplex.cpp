// Program part for barcode demultiplexing

int main()
{
	return 0;
}