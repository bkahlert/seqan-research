// Program part for testing of barcode demultiplexing

int main()
{
	return 0;
}