#include <iostream>
#include <seqan/file.h>
#include <seqan/sequence.h>
#include <seqan/basic.h>

using namespace seqan;



int main()
{

	return 0;
}