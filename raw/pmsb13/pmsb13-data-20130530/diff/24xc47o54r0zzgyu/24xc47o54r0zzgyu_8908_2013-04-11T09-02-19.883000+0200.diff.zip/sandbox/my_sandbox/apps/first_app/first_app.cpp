#include <iostream>
#include <seqan/seq_io.h>

int main()
{
    

    return 0;
}