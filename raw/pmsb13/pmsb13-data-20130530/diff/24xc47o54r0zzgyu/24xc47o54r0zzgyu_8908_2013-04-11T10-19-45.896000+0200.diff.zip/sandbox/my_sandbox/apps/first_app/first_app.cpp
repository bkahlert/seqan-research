#include <seqan/sequence.h>
#include <seqan/index.h>

using namespace seqan;

int main()
{
   

    return 0;
}