#include <seqan>

int main()
{
// Nur ein Test
return 0;
}