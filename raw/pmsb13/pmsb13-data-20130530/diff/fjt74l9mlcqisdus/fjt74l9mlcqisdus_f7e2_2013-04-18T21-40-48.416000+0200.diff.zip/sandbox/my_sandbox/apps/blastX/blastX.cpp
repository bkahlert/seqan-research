// BLASTX IMPLEMENTIERUNG VON ANNKATRIN BRESSIN UND MARJAN FAIZI
// SOFTWAREPROJEKT VOM 2.4. - 29.5.2012
// VERSION VOM 18.APRIL.2013

#include "own_functions.h"

// MAIN FUNKTION -------------------------------------------------------------------------------
int main(int argc, char const ** argv){
	// Klasse Variable enth�lt alle Parameter die der
	// Benutzer �ber Kommandozeile festlegen kann
	Variable comVal;
	// comVal wird mit default Parameter initialisiert
	dafault_values(comVal);
	// Eingabe vom Benutzer wird gelesen und default
	// Parameter wenn Eingabe vorhanden ist ueberschrieben
	if (argc>=2){
		if (PARSE_ARGUMENTS(argc,argv,comVal))
			return 1;
	}
	StringSet<String<int>> Alphabet;
	getAlphabet(comVal.numb_alp,comVal.size_alp,Alphabet);
	cout<<Alphabet[0][18]<<endl;
	return 0;
}
// MAIN FUNKTION -------------------------------------------------------------------------------