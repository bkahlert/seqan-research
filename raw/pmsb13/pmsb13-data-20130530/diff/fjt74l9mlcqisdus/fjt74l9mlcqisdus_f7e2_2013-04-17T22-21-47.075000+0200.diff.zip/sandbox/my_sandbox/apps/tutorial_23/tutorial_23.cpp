#include <seqan/sequence.h>

using namespace seqan;

class{
public:
	String<AminoAcid> Amino;
	String<int> gruppe;
};



int main(){
	return 0;
}