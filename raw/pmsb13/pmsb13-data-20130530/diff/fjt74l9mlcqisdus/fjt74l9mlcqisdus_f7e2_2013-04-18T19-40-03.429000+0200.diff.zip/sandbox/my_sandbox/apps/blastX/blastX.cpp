#include "own_functions.h"
#include <iostream>

int main(int argc,char const ** argv){
 
	std::cout<<f()<<std::endl;
	return 0;
}
