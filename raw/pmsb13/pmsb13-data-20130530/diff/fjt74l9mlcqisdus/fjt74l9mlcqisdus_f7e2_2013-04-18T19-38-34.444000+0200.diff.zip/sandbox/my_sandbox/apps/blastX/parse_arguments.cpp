#include "own_functions.h"
#include <seqan/arg_parse.h>

using namespace std;
using namespace seqan;

int f(){
	return 0;
}