#include "own_functions.h"
#include <iostream>

using namespace std;
using namespace seqan;

int main(int argc, char const ** argv){
 
	cout<<f()<<endl;
	return 0;
}
