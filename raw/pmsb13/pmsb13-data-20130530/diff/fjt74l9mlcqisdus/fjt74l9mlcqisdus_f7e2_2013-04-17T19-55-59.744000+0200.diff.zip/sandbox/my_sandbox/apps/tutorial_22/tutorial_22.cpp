#include <seqan/seq_io.h>


using namespace std;
using namespace seqan;

int main(){
	String<String<Dna>>="ACGTAGACGATGAC";
	

	return 0;
}