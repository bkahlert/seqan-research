#include <seqan/sequence.h>
#include <vector>

using namespace seqan;
using namespace std;


int main(){
	String<IntString> x;
	return 0;
}