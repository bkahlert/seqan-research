#include <seqan/sequence.h>

using namespace seqan;

class ami{
public:
	String<AminoAcid> Amino;
	String<int> gruppe;
};



int main(){
	vector<ami>x;
	return 0;
}