#include <seqan/seq_io.h>


usinging namespace std;
usinging namespace seqan;

int main(){
	String<String<Dna>>="ACGTAGACGATGAC";
	

	return 0;
}