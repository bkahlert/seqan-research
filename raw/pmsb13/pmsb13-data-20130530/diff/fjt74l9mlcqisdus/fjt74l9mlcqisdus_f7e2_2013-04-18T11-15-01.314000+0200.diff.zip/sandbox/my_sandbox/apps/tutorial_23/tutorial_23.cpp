#include <seqan/sequence.h>

using namespace seqan;
using namespace std;


int main(){
	StringSet<String<int>> x;
	resize(x,2,3);
	return 0;
}