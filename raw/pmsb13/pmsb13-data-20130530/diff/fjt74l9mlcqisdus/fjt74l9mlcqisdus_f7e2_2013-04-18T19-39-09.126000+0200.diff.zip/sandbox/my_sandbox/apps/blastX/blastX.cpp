#include "own_functions.h"


int main(int argc, char const ** argv){
 
	cout<<f()<<endl;
	return 0;
}
