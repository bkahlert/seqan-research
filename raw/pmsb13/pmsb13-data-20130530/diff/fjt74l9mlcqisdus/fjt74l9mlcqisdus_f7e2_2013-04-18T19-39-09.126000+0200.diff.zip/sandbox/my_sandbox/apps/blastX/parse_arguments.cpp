#include "own_functions.h"

int f(){
	return 0;
}