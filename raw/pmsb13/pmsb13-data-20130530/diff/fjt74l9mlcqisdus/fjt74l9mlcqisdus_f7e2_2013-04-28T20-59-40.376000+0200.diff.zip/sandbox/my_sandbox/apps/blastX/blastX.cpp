#include <iostream>

int main(){
	std::cout<<"hallo welt";
	return 0;
}