#include <iostream>

void main(){
	std::cout<<"hallo welt";
}