int f(){
	return 1;
}