#include <seqan/sequence.h>

using namespace seqan;

class{
public:
	String<AminoAcid> Aminoacid= "ARNDCEQGHILKMFPSTWYV";
	String<int> gruppe;
	resize(gruppe,20);
};



int main(){
	return 0;
}