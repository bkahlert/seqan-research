#include "own_functions.h"
#include <iosteam>

int main(int argc, char const ** argv){
	std::cout<<f()<<std::endl;
	
	return 0;
}
