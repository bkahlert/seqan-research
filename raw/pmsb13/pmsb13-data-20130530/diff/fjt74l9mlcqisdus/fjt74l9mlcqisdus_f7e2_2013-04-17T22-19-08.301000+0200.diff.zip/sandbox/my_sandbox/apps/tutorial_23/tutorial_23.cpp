#include <seqan/sequence.h>

using namespace seqan;

class{
public:
	String<AminoAcid> Aminoacid= "ARNDCEQGHILKMFPSTWYV";
	String<int> gruppe;
};



int main(){
	return 0;
}