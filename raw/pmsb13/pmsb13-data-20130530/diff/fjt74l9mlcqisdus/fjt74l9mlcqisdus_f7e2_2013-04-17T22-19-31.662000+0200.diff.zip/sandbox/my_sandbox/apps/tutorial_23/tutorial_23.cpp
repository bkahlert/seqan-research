#include <seqan/sequence.h>

using namespace seqan;

class{
public:
	String<AminoAcid> Amino= "ARNDCEQGHILKMFPSTWYV";
	String<int> gruppe;
};



int main(){
	return 0;
}