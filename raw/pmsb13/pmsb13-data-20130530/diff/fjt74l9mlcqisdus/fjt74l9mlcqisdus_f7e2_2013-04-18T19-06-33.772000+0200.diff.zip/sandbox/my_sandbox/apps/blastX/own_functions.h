#ifndef SANDBOX_MY_SANDBOX_APPS_BLASTX_OWN_FUNCTIONS_

using namespace std;
using namespace seqan;

//parse_arguments.cpp
int PARSE_ARGUMENTS(int argc,char const ** argv,Values comVal);




//
struct Values{
	int x;
	//String<char> fasta_file;
	//Values() : fasta_file("database.fa") {}
	//String<char> fastq_file;
	//Values() : fastq_file("reads.fq") {}
};




#define SANDBOX_MY_SANDBOX_APPS_DNA_SIMULATION_MY_HEADER_
#endif  // #ifndef SANDBOX_MY_SANDBOX_APPS_DNA_SIMULATION_MY_HEADER_