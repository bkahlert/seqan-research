#include <seqan/sequence.h>
#include <vector>

using namespace seqan;
using namespace std;


int main(){
	String<String<int>> x;
	return 0;
}