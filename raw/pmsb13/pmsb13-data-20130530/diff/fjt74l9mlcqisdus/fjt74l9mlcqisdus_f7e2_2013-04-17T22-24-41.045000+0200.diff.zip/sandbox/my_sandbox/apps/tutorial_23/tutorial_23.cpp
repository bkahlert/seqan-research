#include <seqan/sequence.h>
#include <vector>

using namespace seqan;

class ami{
public:
	String<AminoAcid> Amino;
	String<int> gruppe;
};



int main(){
	vector<ami>x;
	return 0;
}