#include <seqan/basic.h>
#include <seqan/file.h>

#include "test_10.3.h"


SEQAN_BEGIN_TESTSUITE(test_10d3)
{
    // Call tests.
	SEQAN_CALL_TEST(example1);
}
SEQAN_END_TESTSUITE
