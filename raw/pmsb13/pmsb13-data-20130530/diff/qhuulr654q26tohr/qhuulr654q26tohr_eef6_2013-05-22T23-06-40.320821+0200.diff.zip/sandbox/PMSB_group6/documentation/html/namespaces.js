var namespaces =
[
    [ "seqan", "namespaceseqan.html", null ]
];