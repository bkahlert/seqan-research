var searchData=
[
  ['name',['name',['../structseqan_1_1_memory_sample.html#ac73b3a108cbef1afe887b007fd691b89',1,'seqan::MemorySample::name()'],['../structseqan_1_1_performance_sample.html#ad57c1dc73d7aeead774dc52c2bc9c21e',1,'seqan::PerformanceSample::name()']]]
];
