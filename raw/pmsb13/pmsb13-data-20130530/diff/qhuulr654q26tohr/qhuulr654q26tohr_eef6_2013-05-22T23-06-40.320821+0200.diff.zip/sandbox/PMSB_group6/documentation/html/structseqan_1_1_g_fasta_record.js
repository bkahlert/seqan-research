var structseqan_1_1_g_fasta_record =
[
    [ "GFastaRecord", "structseqan_1_1_g_fasta_record.html#aab6a24e2129b61ff86d56bc2b6b9e9a3", null ],
    [ "GFastaRecord", "structseqan_1_1_g_fasta_record.html#a605409d17ae67a8bd374d135bc6a3cc4", null ],
    [ "id", "structseqan_1_1_g_fasta_record.html#a9fc0e5fb39002e38b528f34906899941", null ],
    [ "seq", "structseqan_1_1_g_fasta_record.html#a55a6d2deb7ef975f28a4aac89c779702", null ]
];