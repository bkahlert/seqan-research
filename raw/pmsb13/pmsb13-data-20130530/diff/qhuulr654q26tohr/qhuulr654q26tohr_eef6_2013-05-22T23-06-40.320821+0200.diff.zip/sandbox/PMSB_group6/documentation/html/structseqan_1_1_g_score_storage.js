var structseqan_1_1_g_score_storage =
[
    [ "GScoreStorage", "structseqan_1_1_g_score_storage.html#ae8c9ba7615d3cb36874aeab402138187", null ],
    [ "maxId", "structseqan_1_1_g_score_storage.html#a264d4bc37f5c32b79a8fbbb5ffd24a4f", null ],
    [ "maxScore", "structseqan_1_1_g_score_storage.html#a6473cc22038cb7f21df5866a6c452883", null ],
    [ "scoreInitialized", "structseqan_1_1_g_score_storage.html#a57225443721c66d5a3e5290775dd350c", null ]
];