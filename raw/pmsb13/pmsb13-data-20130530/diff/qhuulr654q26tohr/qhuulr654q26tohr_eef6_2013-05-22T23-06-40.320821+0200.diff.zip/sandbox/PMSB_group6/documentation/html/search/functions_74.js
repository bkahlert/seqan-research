var searchData=
[
  ['takeaveragevalues',['takeAverageValues',['../structseqan_1_1_performance_sample.html#a3fbe8137dc6639d13c536f1e5f5d9bd2',1,'seqan::PerformanceSample']]]
];
