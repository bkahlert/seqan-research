var test___g_compute_match_8h =
[
    [ "SEQAN_DEFINE_TEST", "test___g_compute_match_8h.html#afb5ca3d16f5b980c14d2b17e33fed87f", null ],
    [ "SEQAN_DEFINE_TEST", "test___g_compute_match_8h.html#aaea717180f6c4cb934fa96f499d1c2d4", null ]
];