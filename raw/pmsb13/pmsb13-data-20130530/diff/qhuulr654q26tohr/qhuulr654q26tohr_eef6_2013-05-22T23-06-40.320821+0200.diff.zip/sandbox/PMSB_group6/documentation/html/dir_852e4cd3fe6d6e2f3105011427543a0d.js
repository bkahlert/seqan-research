var dir_852e4cd3fe6d6e2f3105011427543a0d =
[
    [ "GCluster", "dir_7c825f2ecafdda891832b23d8dfadde7.html", "dir_7c825f2ecafdda891832b23d8dfadde7" ],
    [ "GSearch", "dir_b0c25d6b2172a49ff6b69618f87aac2f.html", "dir_b0c25d6b2172a49ff6b69618f87aac2f" ],
    [ "GStructs", "dir_5bd82506f2b2292737a655567dcd047c.html", "dir_5bd82506f2b2292737a655567dcd047c" ],
    [ "compareFiles.h", "compare_files_8h.html", "compare_files_8h" ],
    [ "computeSensSpec.h", "compute_sens_spec_8h.html", "compute_sens_spec_8h" ],
    [ "GCluster.h", "_g_cluster_8h.html", null ],
    [ "getIdWithoutMaster.h", "get_id_without_master_8h.html", "get_id_without_master_8h" ],
    [ "GSearch.h", "_g_search_8h.html", null ],
    [ "GStructs.h", "_g_structs_8h.html", null ]
];