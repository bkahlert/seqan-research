var structseqan_1_1_g_match =
[
    [ "GMatch", "structseqan_1_1_g_match.html#a2d9ca43c6774fc0a6ecce18a1616cee5", null ],
    [ "GMatch", "structseqan_1_1_g_match.html#a97931c51078da8a996ca32e634b4d10c", null ],
    [ "getScore", "structseqan_1_1_g_match.html#abb18449ea53a23e2d2b00d0ca60e2ad5", null ],
    [ "id", "structseqan_1_1_g_match.html#ae4eac560a806ad0771f1aea4106ffd0d", null ],
    [ "queryId", "structseqan_1_1_g_match.html#a49524158acebda7f2aa2711fa675fe5a", null ],
    [ "querySequence", "structseqan_1_1_g_match.html#a5bf1edefeece4584350a5d8b51bf5931", null ],
    [ "score", "structseqan_1_1_g_match.html#a167782c90ebf893b4ed14dec10751e2d", null ],
    [ "targetSequence", "structseqan_1_1_g_match.html#a13f2c3906e402472217935df02c0c134", null ]
];