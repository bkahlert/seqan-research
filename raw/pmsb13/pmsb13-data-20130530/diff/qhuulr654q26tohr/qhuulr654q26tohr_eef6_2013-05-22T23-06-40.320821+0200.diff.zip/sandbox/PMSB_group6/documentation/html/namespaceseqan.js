var namespaceseqan =
[
    [ "GFastaRecord", "structseqan_1_1_g_fasta_record.html", "structseqan_1_1_g_fasta_record" ],
    [ "GMatch", "structseqan_1_1_g_match.html", "structseqan_1_1_g_match" ],
    [ "GScoreStorage", "structseqan_1_1_g_score_storage.html", "structseqan_1_1_g_score_storage" ],
    [ "MemorySample", "structseqan_1_1_memory_sample.html", "structseqan_1_1_memory_sample" ],
    [ "PerformanceSample", "structseqan_1_1_performance_sample.html", "structseqan_1_1_performance_sample" ]
];