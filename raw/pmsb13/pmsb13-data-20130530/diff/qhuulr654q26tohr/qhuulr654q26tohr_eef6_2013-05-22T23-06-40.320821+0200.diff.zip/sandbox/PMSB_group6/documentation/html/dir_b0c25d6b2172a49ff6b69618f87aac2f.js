var dir_b0c25d6b2172a49ff6b69618f87aac2f =
[
    [ "GCheckClusterMaster.h", "_g_check_cluster_master_8h.html", "_g_check_cluster_master_8h" ],
    [ "GComputeMatch.h", "_g_compute_match_8h.html", "_g_compute_match_8h" ],
    [ "GEvaluateScore.h", "_g_evaluate_score_8h.html", "_g_evaluate_score_8h" ],
    [ "GParseMasterId.h", "_g_parse_master_id_8h.html", "_g_parse_master_id_8h" ],
    [ "GPostProcessMatches.h", "_g_post_process_matches_8h.html", "_g_post_process_matches_8h" ],
    [ "GScore.h", "_g_score_8h.html", "_g_score_8h" ],
    [ "GScorePeptideQGram.h", "_g_score_peptide_q_gram_8h.html", "_g_score_peptide_q_gram_8h" ],
    [ "GSearch_base.h", "_g_search__base_8h.html", "_g_search__base_8h" ],
    [ "GWriteMatches.h", "_g_write_matches_8h.html", "_g_write_matches_8h" ]
];