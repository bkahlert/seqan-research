var _g_compute_match_8h =
[
    [ "GComputeMatch", "_g_compute_match_8h.html#a838fc06a0e80f7e3ffa8c09ed09e907d", null ]
];