var _memory_sample_8h =
[
    [ "MemorySample", "structseqan_1_1_memory_sample.html", "structseqan_1_1_memory_sample" ],
    [ "getPValue", "_memory_sample_8h.html#a943905857877eecc596a716ee29e2d63", null ],
    [ "getVValue", "_memory_sample_8h.html#abfe039b148512fc0d59f04e901432c92", null ],
    [ "parseLine", "_memory_sample_8h.html#abfc1b9b4fd3e0c63871678c69eab5bf2", null ]
];