#ifndef SANDBOX_PMSB_GROUP6_TEST_STRUCTS_PERFORMANCESAMPLE_H_
#define SANDBOX_PMSB_GROUP6_TEST_STRUCTS_PERFORMANCESAMPLE_H_

#include <seqan/basic.h>
#include <seqan/sequence.h>

// A test for strings.
SEQAN_DEFINE_TEST(test_structs_performanceSample)
{
    using namespace seqan;

    SEQAN_FAIL("not yet implemented");
}

#endif  // SANDBOX_PMSB_GROUP6_TEST_STRUCTS_PERFORMANCESAMPLE_H_
