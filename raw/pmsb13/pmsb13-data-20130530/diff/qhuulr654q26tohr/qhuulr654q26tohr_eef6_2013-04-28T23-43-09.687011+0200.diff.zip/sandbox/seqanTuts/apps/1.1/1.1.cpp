#include <iostream>
#include <seqan/file.h>
#include <seqan/sequence.h>
using namespace std;
using namespace seqan;

int main()
{
	bool b = 0;
	cout << b << endl;
	b++;
	cout << b << endl;
	b++;
	cout << b << endl;
    return 0;
}