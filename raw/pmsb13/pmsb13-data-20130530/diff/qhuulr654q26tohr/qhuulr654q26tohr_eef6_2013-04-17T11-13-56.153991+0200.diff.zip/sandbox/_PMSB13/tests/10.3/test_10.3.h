#ifndef SANDBOX_PMSB13_TESTS_10_3_TEST_10_3_H_
#define SANDBOX_PMSB13_TESTS_10_3_TEST_10_3_H_

#include <seqan/basic.h>
#include <seqan/sequence.h>
#include <../../sandbox/PMSB13/apps/10.3/10.3.cpp>

// A test for strings.
SEQAN_DEFINE_TEST(example1)
{
    using namespace seqan;
    using namespace std;

    SEQAN_ASSERT(true);
}

#endif  // SANDBOX_PMSB13_TESTS_10_3_TEST_10_3_H_
