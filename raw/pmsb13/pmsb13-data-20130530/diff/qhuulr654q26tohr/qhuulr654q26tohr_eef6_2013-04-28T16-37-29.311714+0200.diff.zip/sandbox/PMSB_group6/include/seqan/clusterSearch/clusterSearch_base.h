#include <seqan/cluster.h>

using namespace seqan;
using namespace std;

int clusterSearch(int argc, char const ** argv) {
	return cluster(argc, argv);
}