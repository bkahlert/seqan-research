#include <seqan/clusterSearch.h>

using namespace seqan;
using namespace std;

int main(int argc, char const ** argv) {
	return clusterSearch(argc, argv);
}