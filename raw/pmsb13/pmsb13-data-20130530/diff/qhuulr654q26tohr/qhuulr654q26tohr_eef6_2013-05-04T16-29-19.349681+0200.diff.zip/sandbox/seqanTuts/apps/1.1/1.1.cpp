#include <iostream>
#include <seqan/file.h>
#include <seqan/sequence.h>

#include "stdlib.h"
#include "stdio.h"
#include "string.h"

using namespace std;
using namespace seqan;

int main()
{
	int score;
	int a=3;
	if (score==Null)
		cout << "score is null" << endl;
	if(a>score)
		cout << "bigger" << endl;
}