#include <seqan/basic.h>
#include <seqan/file.h>

#include "test_10.3.h"


SEQAN_BEGIN_TESTSUITE(test_10.3)
{
    // Call tests.
	SEQAN_CALL_TEST(test_10.3_strings_example1);
}
SEQAN_END_TESTSUITE
