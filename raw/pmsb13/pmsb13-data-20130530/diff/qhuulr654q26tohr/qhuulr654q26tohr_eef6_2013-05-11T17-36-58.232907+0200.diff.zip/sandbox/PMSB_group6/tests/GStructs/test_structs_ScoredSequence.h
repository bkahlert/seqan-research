#ifndef SANDBOX_PMSB_GROUP6_TEST_STRUCTS_SCOREDSEQUENCE_H_
#define SANDBOX_PMSB_GROUP6_TEST_STRUCTS_SCOREDSEQUENCE_H_

#include <seqan/basic.h>
#include <seqan/sequence.h>

// A test for strings.
SEQAN_DEFINE_TEST(test_structs_ScoredSequence)
{
    using namespace seqan;

    SEQAN_FAIL("not yet implemented");
}

#endif  // SANDBOX_PMSB_GROUP6_TEST_STRUCTS_SCOREDSEQUENCE_H_
