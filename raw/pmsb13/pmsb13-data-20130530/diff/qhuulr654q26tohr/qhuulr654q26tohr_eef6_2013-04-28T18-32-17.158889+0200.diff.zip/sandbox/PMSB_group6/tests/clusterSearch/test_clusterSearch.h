#ifndef SANDBOX_PMSB_GROUP6_TEST_CLUSTERSEARCH_H_
#define SANDBOX_PMSB_GROUP6_TEST_CLUSTERSEARCH_H_

#include <seqan/basic.h>
#include <seqan/sequence.h>

// A test for strings.
SEQAN_DEFINE_TEST(test_clusterSearch_emptyFiles)
{
	using namespace seqan;
	
	SEQAN_FAIL("not yet implemented");
}

SEQAN_DEFINE_TEST(test_clusterSearch_benchmarking_emptyFiles)
{
	using namespace seqan;
	
	SEQAN_FAIL("not yet implemented");
}

#endif  // SANDBOX_PMSB_GROUP6_TESTS_CLUSTERSEARCH_TEST_CLUSTERSEARCH_H_
