#include <iostream>
#include <seqan/file.h>
#include <seqan/sequence.h>
using namespace std;
using namespace seqan;

int main()
{
	cout << "hello" << endl;
    return 0;
}