#!/bin/sh

pandoc Manual.md -o Manual.pdf -H margins.sty --toc

