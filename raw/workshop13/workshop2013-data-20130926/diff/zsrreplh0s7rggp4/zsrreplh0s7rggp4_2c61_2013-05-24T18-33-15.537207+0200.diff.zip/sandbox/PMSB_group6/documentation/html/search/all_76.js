var searchData=
[
  ['virtmemory',['virtMemory',['../structseqan_1_1_memory_sample.html#a22b5eb5bbe60a5d9cb9b6cd6d2160412',1,'seqan::MemorySample']]]
];
