var searchData=
[
  ['gfastarecord',['GFastaRecord',['../structseqan_1_1_g_fasta_record.html',1,'seqan']]],
  ['gmatch',['GMatch',['../structseqan_1_1_g_match.html',1,'seqan']]],
  ['gscorestorage',['GScoreStorage',['../structseqan_1_1_g_score_storage.html',1,'seqan']]]
];
