var dir_5bd82506f2b2292737a655567dcd047c =
[
    [ "GFastaRecord.h", "_g_fasta_record_8h.html", [
      [ "GFastaRecord", "structseqan_1_1_g_fasta_record.html", "structseqan_1_1_g_fasta_record" ]
    ] ],
    [ "GMatch.h", "_g_match_8h.html", [
      [ "GMatch", "structseqan_1_1_g_match.html", "structseqan_1_1_g_match" ]
    ] ],
    [ "GScoreStorage.h", "_g_score_storage_8h.html", [
      [ "GScoreStorage", "structseqan_1_1_g_score_storage.html", "structseqan_1_1_g_score_storage" ]
    ] ],
    [ "MemorySample.h", "_memory_sample_8h.html", "_memory_sample_8h" ],
    [ "PerformanceSample.h", "_performance_sample_8h.html", [
      [ "PerformanceSample", "structseqan_1_1_performance_sample.html", "structseqan_1_1_performance_sample" ]
    ] ]
];