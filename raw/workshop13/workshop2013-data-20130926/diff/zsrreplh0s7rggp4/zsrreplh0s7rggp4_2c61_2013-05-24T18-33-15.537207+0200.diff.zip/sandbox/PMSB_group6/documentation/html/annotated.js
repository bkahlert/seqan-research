var annotated =
[
    [ "seqan", "namespaceseqan.html", "namespaceseqan" ]
];