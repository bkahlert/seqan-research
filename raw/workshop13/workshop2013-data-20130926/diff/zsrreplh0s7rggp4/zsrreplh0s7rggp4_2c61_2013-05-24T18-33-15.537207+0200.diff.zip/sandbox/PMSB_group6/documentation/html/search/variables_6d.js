var searchData=
[
  ['maxid',['maxId',['../structseqan_1_1_g_score_storage.html#a264d4bc37f5c32b79a8fbbb5ffd24a4f',1,'seqan::GScoreStorage']]],
  ['maxscore',['maxScore',['../structseqan_1_1_g_score_storage.html#a6473cc22038cb7f21df5866a6c452883',1,'seqan::GScoreStorage']]]
];
