var searchData=
[
  ['targetsequence',['targetSequence',['../structseqan_1_1_g_match.html#a13f2c3906e402472217935df02c0c134',1,'seqan::GMatch']]]
];
