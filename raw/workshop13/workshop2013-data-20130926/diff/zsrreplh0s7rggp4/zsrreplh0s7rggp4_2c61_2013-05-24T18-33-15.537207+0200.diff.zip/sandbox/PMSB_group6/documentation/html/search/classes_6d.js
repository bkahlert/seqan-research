var searchData=
[
  ['memorysample',['MemorySample',['../structseqan_1_1_memory_sample.html',1,'seqan']]]
];
