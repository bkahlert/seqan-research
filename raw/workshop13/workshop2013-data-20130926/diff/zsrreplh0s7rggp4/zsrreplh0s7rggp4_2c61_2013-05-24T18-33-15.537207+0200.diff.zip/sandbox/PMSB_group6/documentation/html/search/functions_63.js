var searchData=
[
  ['checkstreams',['checkStreams',['../_g_cluster__base_8h.html#a1d2f7cf88f406bc6f82029b9dd15a1c5',1,'checkStreams(SequenceStream &amp;inStream, SequenceStream &amp;outStream, SequenceStream &amp;outMasterStream):&#160;GCluster_base.h'],['../_g_search__base_8h.html#a9966e6517d5f0b9f3ed2d84402fa4621',1,'checkStreams(SequenceStream &amp;myCluster, SequenceStream &amp;myMaster, SequenceStream &amp;myQueries, fstream &amp;myOutput, bool MASTER_FILE_GIVEN):&#160;GSearch_base.h']]],
  ['comparefiles',['compareFiles',['../compare_files_8h.html#aae9c69e4e462c6719fff85cf564fb828',1,'compareFiles.h']]],
  ['computememory',['computeMemory',['../structseqan_1_1_memory_sample.html#a7d0286090f1dc096cad63a5088feb26b',1,'seqan::MemorySample']]],
  ['computesensspec',['computeSensSpec',['../compute_sens_spec_8h.html#aa94ffa5dfc10e978768d5731cd3b2d7a',1,'computeSensSpec.h']]]
];
