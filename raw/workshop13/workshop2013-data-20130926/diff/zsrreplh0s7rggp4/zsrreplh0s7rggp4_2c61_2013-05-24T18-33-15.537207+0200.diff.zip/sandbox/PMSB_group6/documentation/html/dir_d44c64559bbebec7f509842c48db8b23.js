var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "seqan", "dir_852e4cd3fe6d6e2f3105011427543a0d.html", "dir_852e4cd3fe6d6e2f3105011427543a0d" ]
];