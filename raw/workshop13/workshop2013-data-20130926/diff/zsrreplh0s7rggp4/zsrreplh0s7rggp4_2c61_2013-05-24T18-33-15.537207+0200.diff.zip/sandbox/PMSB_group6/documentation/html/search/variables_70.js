var searchData=
[
  ['physmemory',['physMemory',['../structseqan_1_1_memory_sample.html#a9e83041889b177e0b3942e9b10492e4a',1,'seqan::MemorySample']]]
];
