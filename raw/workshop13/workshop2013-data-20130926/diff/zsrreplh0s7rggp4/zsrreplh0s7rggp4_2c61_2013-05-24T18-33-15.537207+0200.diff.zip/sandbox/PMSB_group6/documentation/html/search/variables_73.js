var searchData=
[
  ['score',['score',['../structseqan_1_1_g_match.html#a167782c90ebf893b4ed14dec10751e2d',1,'seqan::GMatch']]],
  ['scoreinitialized',['scoreInitialized',['../structseqan_1_1_g_score_storage.html#a57225443721c66d5a3e5290775dd350c',1,'seqan::GScoreStorage']]],
  ['seq',['seq',['../structseqan_1_1_g_fasta_record.html#a55a6d2deb7ef975f28a4aac89c779702',1,'seqan::GFastaRecord']]],
  ['starttime',['startTime',['../structseqan_1_1_performance_sample.html#aa836fab9103241ea23d5da5642aea14f',1,'seqan::PerformanceSample']]]
];
