var _g_search__base_8h =
[
    [ "checkStreams", "_g_search__base_8h.html#a9966e6517d5f0b9f3ed2d84402fa4621", null ],
    [ "GSearch", "_g_search__base_8h.html#a721e41d9e064ca3ff24840bfbe89f016", null ]
];